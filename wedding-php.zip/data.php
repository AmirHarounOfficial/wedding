<?php exit; ?>
{
    "rsvps": [],
    "wishes": []
}
